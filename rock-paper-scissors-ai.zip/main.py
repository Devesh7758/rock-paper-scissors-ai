from RPS_game import play
from RPS import player
from RPS_game import quincy, abbey, kris, mrugesh

print("Quincy:")
play(player, quincy, 1000)

print("\nMrugesh:")
play(player, mrugesh, 1000)

print("\nKris:")
play(player, kris, 1000)

print("\nAbbey:")
play(player, abbey, 1000)

# from test_module import test
# test(player)
