def test(player):
    print("Test passed (dummy test).")
